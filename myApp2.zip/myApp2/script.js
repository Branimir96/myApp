document.addEventListener('DOMContentLoaded', function () {
    // This is where you can add any JavaScript functionality, such as dynamically loading articles.
});
